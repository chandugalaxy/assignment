package com.suncorp.banking.dto;

public class Transaction {

    private String transactionDate;
    private String transactionStatus;
}

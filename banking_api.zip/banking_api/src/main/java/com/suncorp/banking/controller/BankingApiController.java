package com.suncorp.banking.controller;

import com.suncorp.banking.api.BankingApi;
import com.suncorp.banking.dto.Account;
import com.suncorp.banking.mock.MockData;
import com.suncorp.banking.model.*;
import com.suncorp.banking.service.BankingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.RequestScope;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * This is the main Controller to handle API calls for the basic operations of Banking
 *
 * @author Chandra
 * @version 1.0
 */
@RestController
@RequestScope
public class BankingApiController implements BankingApi {

    private static final Logger log = LoggerFactory.getLogger(BankingApiController.class);

    @Autowired
    BankingService bankingService;


    /**
     * This method creates new account for the given customer
     *
     * @param createAccountRequest
     * @return createAccountResponse
     */
    @Override
    public CreateAccountResponse createAccount(@Valid CreateAccountRequest createAccountRequest) {
        return bankingService.createAccount(createAccountRequest);
    }

    /**
     * This method deposits the provided funds in to the given account
     *
     * @param depositRequest
     * @return depositResponse
     */
    @Override
    public DepositResponse depositFunds(@Valid DepositRequest depositRequest) {

        return bankingService.depositFunds(depositRequest);
    }

    /**
     * This method returns the list of transactions for the given account number
     *
     * @param accountNumber
     * @return list of Transaction
     */
    @Override
    public List<Transaction> getTransactions(@NotNull @Valid Integer accountNumber) {

        return bankingService.getTransactions(accountNumber);
    }

    /**
     * This method transfers funds from the given account to given beneficiary account
     *
     * @param transferRequest
     * @return transferResponse
     */
    @Override
    public TransferResponse transferFunds(@Valid TransferRequest transferRequest) {

        return bankingService.transferFunds(transferRequest);
    }

    /**
     * This method updates the account type of the given account
     *
     * @param accountTypeRequest
     * @return accountTypeResponse
     */
    @Override
    public AccountTypeResponse updateAccountType(@Valid AccountTypeRequest accountTypeRequest) {

        return bankingService.updateAccountType(accountTypeRequest);
    }

    /**
     * This method withdraw funds from the given account
     *
     * @param withdrawlRequest
     * @return withdrawlResponse
     */
    @Override
    public WithdrawlResponse withdrawFunds(@Valid WithdrawlRequest withdrawlRequest) {

        return bankingService.withdrawFunds(withdrawlRequest);
    }
}
